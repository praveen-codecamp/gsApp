(function(){
    
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
     $('#navWrapper').toggleClass('show');
     $(this).toggleClass("collapsed")
    });
    
    
 
    
})()