(function(){
    
    /*Creating a function for header*/
    function headerCtrlFn(){
        var vm = this;
        vm.brandName = "innRoad";
        vm.brandLogo = "../../img/innroad-logo.png";
        vm.navItems = ["Frontdesk","Accounts","Guest Services","Inventory","Setup","Admin","Night Audit","Reports"];
        vm.gsTemplate = "app/guestservices/guestservices.html";
        
        vm.loadView = function(param){
            if(param == "guestservices"){
                vm.loadTemplate = vm.gsTemplate;
            }
        }
    }
    
    
    
    /*Creating Header Controller*/
    angular.module("header")
    .controller("headerCtrl",["$scope",headerCtrlFn]);
    
})();