(function(){
    
    angular.module("guestservices",[]);
    
})();