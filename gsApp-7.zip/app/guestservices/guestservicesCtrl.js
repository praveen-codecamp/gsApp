(function(){
    
    function gsCtrlFn(){
        
    }
    
    
    angular.module("guestservices")
    .controller("gsCtrl",["$scope",gsCtrlFn])
    
    
    
})();