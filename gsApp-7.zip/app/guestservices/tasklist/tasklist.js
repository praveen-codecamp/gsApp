(function(){
    
    angular.module("tasklist",[]);
    
})();