(function(){
    
    function tasklistCtrlFn(){
        
        
        
    }
    
    
    angular.module("tasklist")
    .controller("tasklistCtrl",["$scope",tasklistCtrlFn])
    
})();